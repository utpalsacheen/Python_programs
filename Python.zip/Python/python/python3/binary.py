if __name__ == '__main__':
    n = int(input())
    print("Finding binary representation on number: ", n)

    binary = []
    while (n>0):
        binary.append(str(n % 2))
        n = n // 2
        if n == 1:
            binary.append(str(1))
            true = False

    binary = binary[::-1]
    string = ''.join(binary)
    print(string)

    num = 0
    max = 0
    print(type(binary))
    for n in range(0,len(binary)):
        if (binary[n] == '1'):
            print("vallue: ",binary[n])
            num += 1
            if max < num:
                max = num
        elif binary[n] == '0':
                num = 0
    print("Max: ",max)


#Print a single base- integer denoting the maximum number of consecutive 's in the binary representation of n.
# binary representation of 13 is 1101
#Sample Input 1
#
#5
#Sample Output 1
#
#1
#Sample Input 2
#
#13
#Sample Output 2
#
#2
