"""
Task 
Given an array, a, of size n distinct elements, sort the array in ascending order using the Bubble Sort algorithm above. Once sorted, print the following 3 lines:

    Array is sorted in numSwaps swaps. 
    where  numSwaps is the number of swaps that took place.
    First Element: firstElement 
    where firstElement is the first element in the sorted array.
    Last Element: lastElement 
    where lastElement is the last element in the sorted array.
  
  Hint: To complete this challenge, you will need to add a variable that keeps a running tally of all swaps that occur during execution.

    Input Format

    The first line contains an integer, n, denoting the number of elements in array . 
    The second line contains n space-separated integers describing the respective values of .

    Output Format

    Print the following three lines of output:

    Array is sorted in numSwaps swaps. 
    where numSpace is the number of swaps that took place.
    First Element: firstElement 
    where firstElement is the first element in the sorted array.
    Last Element: lastElement 
    where lastElement is the last element in the sorted array.
    Sample Input 0

    3
    1 2 3
    Sample Output 0

    Array is sorted in 0 swaps.
    First Element: 1
    Last Element: 3

"""

import sys

n = int(input().strip())
a = list(map(int, input().strip().split(' ')))

print("array: ", a)
numSwaps = 0

for i in range(len(a)):
    for j in range(len(a)-1):
        if a[j] > a[j+1]:
            tmp = a[j]
            a[j] = a[j+1]
            a[j+1] = tmp
            numSwaps += 1

print("Swaps: ", numSwaps)
print(a)

print("Array is sorter in " + str(numSwaps) + " swaps.")
print("First Element: ", a[0])
print("Last Element: ", a[-1])
