def invite(attendees):
    for name in attendees:
        print(name.title() + ", request you to please join me for dinner.")

def invite_more(where, who, list1):
    list1.insert(int(where), who)

def invite_only_two(attendees):
    for name in attendees:
        who = attendees.pop()
        print(who.title() + ", sorry we can only invite two people for dinner!\n")
        if (len(attendees) == 2):
            print("Count reached: " + str(len(attendees)))
            break

names =[ "ramani", "ramesh", "jatheen", "ishaan", "nishka"]
invite(names)

cant_make = "jatheen"

print(cant_make + ", cant make it to the dinner tonight.")
names.remove(cant_make)

names.append("rahul")

invite(names)

invite_more(0, "roshan", names)
invite_more(len(names)/2, "arin", names)
names.append("divya")

print("\n\n\n")

invite(names)

invite_only_two(names)

print(str(len(names)) + "remaining")
invite_only_two(names)
invite(names)

del names[1]
del names[0]

print(str(len(names)) + " remaining")
