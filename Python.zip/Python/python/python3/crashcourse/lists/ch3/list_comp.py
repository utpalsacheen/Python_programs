# use a list comprehension to generate a list of the first 10 cubes
cubes = [values ** 3 for values in range(1,11)]
print(cubes)
