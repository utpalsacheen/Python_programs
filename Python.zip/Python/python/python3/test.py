from collections import deque

"""
Task 

The height of a binary search tree is the number of edges between the tree's root and its furthest leaf. You are given a pointer, root , pointing to the root of a binary search tree. Complete the getHeight function provided in your editor so that it returns the height of the binary search tree.

Input Format

The locked stub code in your editor reads the following inputs and assembles them into a binary search tree: 
    The first line contains an integer, n, denoting the number of nodes in the tree. 
    Each of the  subsequent lines contains an integer, data, denoting the value of an element that must be added to the BST.

    Output Format

    The locked stub code in your editor will print the integer returned by your getHeight function denoting the height of the BST.

    Sample Input

    7
    3
    5
    2
    1
    4
    6
    7
    Sample Output

    3

"""

class Node:
    def __init__(self, data):
        #self.right = self.left = None
        self.right = None
        self.left  = None
        self.data  = data

class Solution:

    printarr = []
    def insert(self, root, data):
        if root == None:
            return Node(data)
        else:
            if data <= root.data:
                cur = self.insert(root.left, data)
                root.left = cur
            else:
                cur = self.insert(root.right, data)
                root.right = cur
        return root

    def getHeight(self, root):
        if root is None:
            return -1
        return max(self.getHeight(root.left), self.getHeight(root.right)) + 1


    def givenLevelPrint(self, root, level):
        if root is None:
            return
        if level == 1:
            #print(root.data)
            self.printarr.append(root.data)
        elif level > 1:
            self.givenLevelPrint(root.left, level-1)
            self.givenLevelPrint(root.right, level-1)


    def levelOrderPrint(self, root):
        h = self.height(root)
        for i in range(1, h+1):
            self.givenLevelPrint(root, i)

    def height(self, root):
        if root is None:
            return 0
        else:
            lheight = self.height(root.left)
            rheight = self.height(root.right)

            if lheight > rheight:
                return lheight+1
            else:
                return rheight+1



def printTree(root):
    buf = deque()
    output = []
    if root is None:
        print('$')
    else:
        buf.append(root)
        count, nextCount = 1, 0
        while count:
            node = buf.popleft()
            if node:
                output.append(str(node.data))
                count -= 1
                for n in (node.left, node.right):
                    if n:
                        buf.append(n)
                        nextCount += 1
                    else:
                        buf.append(None)
            else:
                buf.append('$')
            if not count:
                print(output)
                output = []
                count, nextCount = nextCount, 0
        output.extend(['$']*len(buf))
        print(output)

T=int(input())
myTree=Solution()
root=None
for i in range(T):
    data=int(input())
    root=myTree.insert(root,data)
height=myTree.getHeight(root)

printTree(root)

#myTree.levelOrderPrint(root)

#print(' '.join(str(e) for e in myTree.printarr))




