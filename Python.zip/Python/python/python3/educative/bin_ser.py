def bin_rec(a, k, st, en):
    if st >= en:
        return -1

    mid = st + (en - st) // 2
    if a[mid] == k:
        return mid

    if k > a[mid]:
        return bin_rec(a, k, mid+1, en)
    elif k < a[mid]:
        return bin_rec(a, k, st, mid-1)

    return -1

def bin_ser(a, k):
    st = 0
    en = len(a) -1

    while(st < en):
        mid = st + (en - st) // 2

        if(a[mid] == k):
            return mid
        elif(k < a[mid]):
            en = mid - 1
        elif(k > a[mid]):
            st = mid + 1

    return -1


a = [1,3,4,6,7,9,10]
value = bin_ser(a, 9)
print(value)

value = bin_ser(a, 12)
print(value)

value = bin_rec(a, 9, 0, len(a) -1)
print(value)
value = bin_rec(a, 12, 0, len(a) -1)
print(value)

