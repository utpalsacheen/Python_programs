class Node():
    def __init__(self, val):
        self.val = val
        self.nextp = None

    def printv(self):
        head = self
        while head.nextp != None:
            print(head.val)
            head = head.nextp


def deleten(head, key):
    # given head of LL and a key, delete node with this given key from the LL
    prev = None
    cur = head
    while cur is not None:
        if key == cur.val:
            if cur == head:
                head = head.nextp
                cur = head
            else:
                prev.nextp = cur.nextp
                cur = cur.nextp
        # key not found in list
        else:
            prev = cur
            cur = cur.nextp

    if cur is None:
        return head

    head.printv()
    return head




def delDup(head):
    if head == None: 
        return head

    dup = set()
    dup.add(head.val)
    cur = head

    while cur.nextp != None:
        print("val: " + str(cur.val))
        print("dup set: " + str(dup))
        if cur.nextp.val in dup:
            print("Found d: " + str(cur.nextp.val))
            print("h next : " + str(cur.nextp.nextp.val))
            cur.nextp = cur.nextp.nextp

        else:
            dup.add(cur.nextp.val)
            cur = cur.nextp

    return head


n1 = Node(1)
n2 = Node(2)
n3 = Node(3)
n4 = Node(2)
n5 = Node(1)
n6 = Node(6)

n1.nextp = n2
n2.nextp = n3
n3.nextp = n4
n4.nextp = n5
n5.nextp = n6
n6.nextp = None
listl = n1
listl.printv()
print("\n")
l1 = delDup(listl)
print("\n")
print("\n")
l1.printv()
print("\n")

l2 = deleten(l1, 2)
l2.printv()
