""" Given the pointer/reference to the had of a singly linked list, reverse it and return the pointer/reference to the head of reversed linked list """
""" Runtime Complexity - Linear, O(n) """
""" Memory Complexity - Constant, O(1) as no extra memory is required for the iterative solution"""

def reverseLinkedList(head):
    if (head == None or head.nextv == None):
        return head

    list_to_do = head.nextv
    rlist = head
    rlist.nextv = None

    while list_to_do != None:
        temp = list_to_do
        list_to_do = list_to_do.nextv
        temp.nextv = rlist
        rlist = temp

    return rlist

""" Runtime Complexity - Linear, O(n) """
""" Memory Complexity - Linear, O(n) as no extra memory is required for the iterative solution"""
""" Note: recursive solution uses stack. OS allocates stack memory and this solution can run out of memory for really large linked lists """
def revRec(head):
    if (head == None or head.nextv == None):
        return head

    rlist =  revRec(head.nextv)

    head.nextv.nextv = head
    head.nextv = None
    return rlist

def sorted_insert(head, node):
    if node == None:
        return head

    if head == None or node.val <= head.val:
        node.nextp = head
        return head

    cur = head
    while cur.nextp != None and cur.nextp.val < node.val:
        cur = cur.nextp
    node.nextp = cur.nextp
    cur.nextp = node

    return head


def insertion_sortll(llist):
    sortedl = None
    cur = llist

    while cur is not None:
        temp = cur.nextv
        sortedl = sorted_insert(sortedl, cur)
        cur = temp

    return sortedl




class Node():
    def __init__(self, val=None):
        self.val = val
        self.nextv = None

    def printVal(self):
        print_val = self
        while print_val is not None:
            print(print_val.val)
            print_val = print_val.nextv


#list1 = SLinkedList()
node1 = Node(12)
node2 = Node(21)
node3 = Node(32)
node4 = Node(43)
node5 = Node(45)
node1.nextv = node2
node2.nextv = node3
node3.nextv = node4
node4.nextv = node5
node1.headv = node1
node1.printVal()



print("\n")
rlist = reverseLinkedList(node1)
rlist.printVal()
print("\n")

rlist1 = revRec(rlist)
rlist1.printVal()
