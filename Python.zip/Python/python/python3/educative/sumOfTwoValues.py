#!/usr/bin/python
""" Sum of two value - using hash set """
""" Runtime complexity: Linear, O(n) """
""" Memory Complexity: Linear, O(n) """


# find_sum_of_two function return true if there are two values in array whos
# sum to the value and returns false otherwise - using hash set

def find_sum_of_two(arr, sum):
    found_values = set()
    for a in arr:
        if sum - a in found_values:
            return True
        found_values.add(a)
    return False

""" Sum of two value - using sorted array """
""" Runtime complexity: Linearithmic, O(nlogn) """
""" Memory Complexity: Constant, O(1) """
def find_sum_of_two_sol_2(arr, sum):
    st = 0
    end = len(arr) - 1
    arr.sort()
    while st < end:
        if arr[st] + arr[end] == sum:
            return True

        if arr[st] + arr[end] > sum:
            end -= 1
        else:
            st += 1
    return False

def test(a, val, expected):
    output = find_sum_of_two(a, val)
    print("exist(A, " + str(val) + ") = " + str(output) + "\n")
    assert expected == output
    output = find_sum_of_two_sol_2(a, val)
    print("exist(A, " + str(val) + ") = " + str(output) + "\n")
    assert expected == output

def main():
    # using hash set
    v = [2,1,8,4,7,3]
    test(v, 3, True)
    test(v, 20, False)
    test(v, 10, True)
    test(v, 2, False)

main()
