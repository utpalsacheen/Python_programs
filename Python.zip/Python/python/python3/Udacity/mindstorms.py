import turtle, time

def draw_square(some_turtle):
    for i in range(4):
        some_turtle.forward(100)
        some_turtle.right(90)

def draw_shapes():
    window = turtle.Screen()
    window.bgcolor("red")

    brad = turtle.Turtle()  # create an instance of class Turtle
    brad.shape("turtle")
    brad.color("white")
    brad.speed(5)
    for n in range(36):
        brad.right(10)
        draw_square(brad)


#    angie = turtle.Turtle()
#    angie.shape("arrow")
#    angie.color("black")
#    angie.circle(100)
#
#    micki = turtle.Turtle()
#    micki.shape("turtle")
#    micki.color("green")
#    micki.speed(7)
#    for n in range(3):
#        micki.forward(100)
#        micki.right(120)

    window.exitonclick()

draw_shapes()
