import webbrowser
import os, time

print("This program started on " + time.ctime()) # ctime gives the current time of execution

for n in range(3):
    time.sleep(2*60*60)
    webbrowser.open("https://www.youtube.com/watch?v=JDjTJ6lkb-8&list=RDJDjTJ6lkb-8&start_radio=1")
