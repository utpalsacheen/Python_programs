import turtle

def draw_triangle(some_turtle, side):
    for i in range(4):
        some_turtle.forward(100)
        if (side):
            some_turtle.right(45)
            side = False
        else:
            some_turtle.right(135)
            side = True


def draw_art():
    window = turtle.Screen()
    window.bgcolor("red")

    brad = turtle.Turtle()
    brad.shape("turtle")
    brad.color("white")
    brad.speed(5)
    for n in range(36):
        s = True
        draw_triangle(brad, s)
        brad.right(360/36)
    brad.forward(300)

    window.exitonclick()



draw_art()
