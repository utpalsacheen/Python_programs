def qa(string):
    arr = list(string)
    size = len(arr)
    n = size - 1
    for i in range(size//2):
        if arr[i].isalnum() and arr[n].isalnum():
            k = arr[i]
            arr[i] = arr[n]
            arr[n] = k
            n -= 1

    print("rev array: " + str(arr))


qa("a!!!b.c.d,e'f,ghi")
qa("i!!!h.g.f,e'd,cba")
