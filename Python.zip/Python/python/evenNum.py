for n in range(2, 10):
   if n % 2 == 0:
      print(n, 'is an even number')
      continue
   else:
      print(n, 'is an odd number')

