def bub_s(arr):
    si = len(arr)
    print("size: " + str(si))

    for n in range(si):
        i = 0
        for j in range(1,si): 
            print("cmp: " + str(arr[i]) + " > " + str(arr[j]))
            if arr[i] > arr[j]:
                elem = arr[i]
                arr[i] = arr[j]
                arr[j] = elem
                i += 1
            else:
                i += 1
        print("arr: " + str(arr))
    print("s  arr: " + str(arr))




arr = [64, 34, 25, 12, 22, 11, 90]
bub_s(arr)
