import sys

a = int(raw_input().strip())
b = int(raw_input().strip())

print(float(a)/float(b))
