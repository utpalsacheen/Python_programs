#!/usr/bin/python

def count_bits(x):
    num_bits = 0
    while x:
        print("num_bits: " + str(num_bits))
        num_bits += x & 1    # bitwise AND operator
        print("num_bits &: " + str(num_bits))
        x >>= 1
        print("x: " + str(x))
    print(" return num_bits: " + str(num_bits))
    return num_bits


count_bits(111)
