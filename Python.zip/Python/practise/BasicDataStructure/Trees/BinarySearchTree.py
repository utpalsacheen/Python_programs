"""
Problem: Binary Search Tree

Binary Search Tree is sometimes called ordered or sorted binary
tree, and it keeps its value in sorted order, so that look up
and other operations can use the principle of binary search

An important property of the binary search tree is that the value of 
a binary search tree node is larger than the value of the offspring of its
left child, but smaller that the value of the offspring of its right child

          (4)
        /     \
      (3)     (7)
     /        /
   (2)      (5)
   /          \
 (1)           (6)
  
- Inserting a new node to the Binary Search Tree
- Searching for the node value... or not...

"""

class BinarySearchTree():
	def __init__(self, value):
		self.value = value
		self.leftChild = None
		self.rightChild = None

	def insert_node(self, value):
		if value <= self.value and self.leftChild:
			self.leftChild.insert_node(value)
		elif value <= self.value:
			self.leftChild = BinarySearchTree(value)
		elif value > self.value and self.rightChild:
			self.rightChild.insert_node(value)
		else:
			self.rightChild = BinarySearchTree(value)

	def find_value(self, value):
		if value < self.value:
			return self.leftChild.find_value(value)
		elif value > self.value:
			return self.rightChild.find_value(value)

		return self.value == value

	# Delete the current node from the BST
	# Set the None value to all three attributes of the BinarySearchTree
	# object
	def clear_node(self):
		self.value = None
		self.leftChild = None
		self.rightChild = None

	# Find the minimum value in the BST
	# The left most node in the BST has the minimum value
	def find_min_value(self):
		if self.leftChild:
			return self.leftChild.find_min_value()
		else:
			return self.value

	def remove_node(self, value, parent):
		if value < self.value and self.leftChild:
			self.leftChild.remove_node(value, self)  # self here is the parent
		elif value < self.value:
			return False
		elif value > self.value and self.rightChild:
			self.rightChild.remove_node(value, self)
		elif value > self.value:
			return False
		else:
			# if the node to be deleted is the leftchild of its parent and the node's 
			# left child and right child is none
			if self.leftChild == None and self.rightChild == None and self == parent.leftChild:
				parent.leftChild = None
				self.clear_node()
			# if the node to be deleted is the right child of its parent and the node's
			# left child and right child is none
			elif self.leftChild == None and self.rightChild == None and self == parent.rightChild:
				parent.rightChild = None
				self.clear_node()
			# if the node to be deleted has a left child and no right child and the node is the left
			# child of its parent
			elif self.leftChild and self.rightChild == None and self == parent.leftChild:
				parent.leftChild = self.leftChild
				self.clear_node()
			# if node to be deleted has a right child and no left child and the node is the 
			# right child of its parent
			elif self.leftChild and self.rightChild == None and self == parent.rightChild:
				parent.rightChild = self.leftChild
				self.clear_node()
			# if node to be deleted has a right child and no left child and the node is the right
			# child of its parent
			elif self.rightChild and self.leftChild == None and self == parent.rightChild:
				parent.rightChild = self.rightChild
				self.clear_node()
			# if node to be deleted has a right child and no left child and the node is the left
			# child of its parent
			elif self.rightChild and self.leftChild == None and self == parent.leftChild:
				parent.leftChild = self.rightChild
				self.clear_node()
			# if node to be deleted has both left and right child, we get the node with the 
			# smallest value and set it to the value of the current node. Finish it by removing 
			# the smallest node
			else:
				self.value = self.rightChild.find_min_value()
				self.rightChild.remove_node(self.value, self)

			return True

	def preorder_traversal(self):
		print self.value
		if self.leftChild:
			self.leftChild.preorder_traversal()
		if self.rightChild:
			self.rightChild.preorder_traversal()

	def inorder_traversal(self):
		if self.leftChild:
			self.leftChild.inorder_traversal()
		print self.value
		if self.rightChild:
			self.rightChild.inorder_traversal()

	def postorder_traversal(self):
		if self.leftChild:
			self.leftChild.postorder_traversal()
		if self.rightChild:
			self.rightChild.postorder_traversal()
		print self.value


def main():
	bst = BinarySearchTree(15)
	bst.insert_node(10)
	bst.insert_node(8)
	bst.insert_node(12)
	bst.insert_node(20)
	bst.insert_node(17)
	bst.insert_node(25)
	bst.insert_node(19)

	assert bst.find_value(10) == True, 'Value not found in BST'
	assert bst.find_value(19) == True, 'Value not found in BST'

	bst.inorder_traversal()
	print
	bst.remove_node(15, None)
	bst.inorder_traversal()


if __name__ == '__main__':
	main()
