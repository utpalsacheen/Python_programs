"""
You have a string s that consists of English letters, punctuation marks, whitespace
characters, and brackets. It is gauranteed that the paranthesis in s form a regular bracket
sequence.

Your task is to reverse the strings contained in each pair of matching parentheses, starting from 
the innermost pair. The results string should not contain any paranthesis.

Example:
For string s = "a(bc)de, the output should be reverseParentheses(s) = "acbde"
"""

def reverseParentheses(s):
    s = list(s)
    stack = []
    i = 0
    while i < len(s):
        if s[i] == '(':
            # add the index to the stack
            # keep track of the index for '(' 
            stack.append(i)
        elif s[i] == ')':
            # pop the index stored in stack for '('
            j = stack.pop()
            # reverse the sublist from index j+1 to i
            s[j+1:i] = s[j+1:i][::-1]
        i += 1

    print(s)

    # " join the list to string leaving the '(' and ')' characters
    return ''.join([i for i in s if i not in ('(', ')')])

# main()
s1 = "a(bc)de"
s2 = "a(bcdefghijkl(mno)p)q"
s3 = "co(de(fight)s)"
s4 = "Code(Cha(lle)nge)"
s5 = "The ((quick (brown) (fox) jumps over the lazy) dog)"
assert reverseParentheses(s1) == "acbde", "Reverse Parentheses \
did not reverse the string to acbde"
assert reverseParentheses(s2) == "apmnolkjihgfedcbq", "Reverse Parentheses \
did not reverse the string to apmnolkjihgfedcbq"
assert reverseParentheses(s3) == "cosfighted", "Reverse Parentheses \
did not reverse the string to cosfighted"
assert reverseParentheses(s4) == "CodeegnlleahC", "Reverse Parentheses \
did not reverse the string to CodeegnlleahC"
assert reverseParentheses(s5) == "The god quick nworb xof jumps over the lazy", "Reverse Parentheses \
did not reverse the string to The god quick nworb xof jumps over the lazy"