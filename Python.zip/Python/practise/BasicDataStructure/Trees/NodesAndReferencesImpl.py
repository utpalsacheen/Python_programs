#!/usr/bin/python


"""
Problem: Trees:

Implementation: Nodes and References technique
"""

class Stack:
	def __init__(self):
		self.items = []

	def push(self, item):
		self.items.append(item)

	def pop(self):
		return self.items.pop()


# Create a Binary Tree class
class BinaryTree:
	def __init__(self, rootObj):
		self.key = rootObj
		self.leftChild = None
		self.rightChild = None

	def insertLeft(self, newNode):
		if self.leftChild == None:
			self.leftChild = BinaryTree(newNode)
		else:
			t = BinaryTree(newNode)
			t.leftChild = self.leftChild
			self.leftChild = t

	def insertRight(self, newNode):
		if self.rightChild == None:
			self.rightChild = BinaryTree(newNode)
		else:
			t = BinaryTree(newNode)
			t.rightChild = self.rightChild
			self.rightChild = t

	def getRightChild(self):
		return self.rightChild

	def getLeftChild(self):
		return self.leftChild

	def setRootVal(self, newVal):
		self.key = newVal

	def getRootVal(self):
		return self.key

	def printTree(self):
		if self.leftChild:
			self.leftChild.printTree()
		print(self.key)
		if self.rightChild:
			self.rightChild.printTree()

def buildParseTree(fpexp):
	# split the expression to a list
	fplist = fpexp.split()
	# create a stack
	pStack = Stack()
	# create a binary tree
	eTree = BinaryTree('')
	# push the tree to the stack
	pStack.push(eTree)

	# variable to hold the currentTree
	currentTree = eTree

    # iterate through the list of expression values
	for i in fplist:
		if i == '(':
			# create a empty left child
			currentTree.insertLeft('')
			pStack.push(currentTree)
			# make the leftChild as the currentTree
			currentTree = currentTree.getLeftChild()
		elif i not in '+-*/':
			currentTree.setRootVal(eval(i))
			parent = pStack.pop()
			currentTree = parent
		elif i in '+-*/':
			currentTree.setRootVal(i)
			currentTree.insertRight('')
			pStack.push(currentTree)
			currentTree = currentTree.getRightChild()
		elif i == ')':
			currentTree = pStack.pop()
		else:
			raise ValueError("Unknown Operator!")

	return eTree


# preorder Tree Traversal
def preOrder(fTree):
	if fTree:
		print(fTree.getRootVal())
		preorder(fTree.getLeftChild())
		preorder(fTree.getRightChild())

# portOrder Tree traversal
def postOrder(fTree):
	sVal = ''
	if fTree:
		sVal = '(' + postOrder(fTree.getLeftChild())
		sVal = sVal + postOrder(fTree.getRightChild())
		sVal = sVal + str(fTree.getRootVal()) + ')'
	return sVal

# inorder tree traversal
def inOrder(fTree):
	sVal = ''
	if fTree:
		sVal = '(' + inOrder(fTree.getLeftChild())
		sVal = sVal + str(fTree.getRootVal())
		sVal = sVal + inOrder(fTree.getRightChild()) + ')'
	return sVal



"""
def evaluate(parseTree):
	opers = {'+' : operator.add, '-' : operator.sub, '*' : operator.mul, '/' : operator.truediv}

	leftC = parseTree.getLeftChild()
	rightC = parseTree.getRightChild()

	if leftC and rightC:
		fn = opers[parseTree.getRootVal()]
		return fn(evaluate(leftC), evaluate(rightC))
	else:
		return parseTree.getRootVal()

"""

# main
"""r = BinaryTree('a')
r.insertLeft('b')
r.insertRight('c')
r.insertLeft('d')
r.insertRight('e')
r.printTree()
print()
"""
val = buildParseTree('(3+(4*5))')
val.printTree()

x = BinaryTree('*')
x.insertLeft('+')
l = x.getLeftChild()
l.insertLeft(4)
l.insertRight(5)
x.insertRight(7)

print(inOrder(x))
print(postOrder(x))






