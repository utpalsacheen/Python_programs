#!/usr/bin/python

"""
Porblem: Binary Heap

"""

class BinaryHeap:
	def __init__(self):
		self.heapList = [0]
		self.currentSize = 0

    # take over and position the new item properly
	def percUp(self, i):
		# when adding an item to the heap, if the key is smaller than the
		# parent key, percolate the node to the parent
		while i // 2 > 0:
			# heapList[i//2] is the parent node
			if self.heapList[i] < self.heapList[i // 2]:
				temp = self.heapList[i //2]
				self.heapList[i // 2] = self.heapList[i]
				self.heapList[i] = temp
			i = i // 2

	def insert(self, i):
		self.heapList.append(i)
		self.currentSize += 1
		self.percUp(self.currentSize)

	def percDown(self, i):
		while (i * 2) <= self.currentSize:
			mc = self.minChild(i)
			print(mc)
			if self.heapList[i] > self.heapList[mc]:
				temp = self.heapList[i]
				self.heapList[i] = self.heapList[mc]
				self.heapList[mc] = temp
		i = mc

	def minChild(self, i):
		if i * 2 + 1 > self.currentSize:
			return i * 2
		else:
			if self.heapList[i*2] < self.heapList[i*2+1]:
				return i * 2
			else:
				return i * 2 + 1

	def delMin(self):
		retval = self.heapList[1]
		self.heapList[1] = self.heapList[self.currentSize]
		self.currentSize = self.currentSize - 1
		self.heapList.pop()
		self.percDown(1)
		return retval

	def buildHeap(self, aList):
		i = len(aList) // 2
		self.currentSize = len(aList)
		self.heapList = [0] + aList[:]
		while i > 0:
			self.percDown(i)
			i -= 1


# main
bh = BinaryHeap()
bh.buildHeap([9,5,6,2,3])

print(bh.delMin())
print(bh.delMin())

