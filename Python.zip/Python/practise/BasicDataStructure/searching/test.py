"""
Binary Search

"""
def binarySearch(a, find):
	if len(a) == 0:
		return False
	else:
		mid = len(a) // 2
		if a[mid] == find:
			return True
		else:
			if a[mid] > find:
1				return binarySearch(a[:mid], find)
			else:
				return binarySearch(a[mid+1:], find)



# given a sorted array:
a = [1,2,3,4,5,6,7,8,9,10,12,13,14,15,16]
find = 12
found = binarySearch(a, find)
print found
assert found == True, "Failed to find 12 in the array"