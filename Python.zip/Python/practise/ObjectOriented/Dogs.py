# Parent class
class Pets:
	dogs = []

	def __init__(self, dogs):
		self.dogs = dogs

# Parent class
class Dog:
    # class attribute
    species = 'mammal'

    # Instance Attributes
    def __init__(self, name, age):
    	self.name = name
    	self.age = age

    # class/instance methods
    def description(self):
    	return "{} is {} years old.".format(self.name, self.age)

    def speak(self, sound):
    	return "{} says {}".format(self.name, sound)


# Child class ( inherits from Dog class)
class RussellTerrier(Dog):
	def run(self, speed):
		return "{} runs {}".format(self.name, speed)


# child class ( inherits from Dog class)
class BullDog(Dog):
	def run(self, speed):
		return "{} runs {}".format(self.name, speed)


class SomeBreed(Dog):
	pass


# child class overiding the class attribute
class SomeOtherBreed(Dog):
	species = "reptile"



def get_oldest_dog(*args):
	return max(args)


# main

# Instantiate the Dob Object
philo = Dog("Philo", 5)
mikey = Dog("Mikey", 6)
bruno = Dog("Bruno", 8)
juno = Dog("Juno", 10)
barnee = Dog("Barnee", 12)

# Access the instance attributes
print("{} is {} and {} is {}.".format(philo.name, philo.age, mikey.name, mikey.age))

# is Philo a mammal?
if philo.species == "mammal":
	print("{0} is a {1}!".format(philo.name, philo.species))

print("The oldest dog is {} years old.".format(get_oldest_dog(philo.age, mikey.age, bruno.age, juno.age, barnee.age)))

# call our instance methods
print(mikey.description())
print(mikey.speak("Gruff Gruff"))


# child classes inherit attributes and
# behaviors from the parent class
jim = BullDog("Jim", 12)
print(jim.description())

# child classes have specific attributes
# and behaviors as well
print(jim.run("slowly"))

# is Jim an instance of Dog()?
print(isinstance(jim, Dog))

# is Julie an instance of Dog()?
julie = Dog("Julie", 100)
print(isinstance(julie, Dog))

# is johnny walker an instance of Bulldog()
johnnywalker = RussellTerrier("johnnywalker", 4)
print(isinstance(johnnywalker, BullDog))

# is julie an instance of jim?
#print(isinstance(julie, jim))

"""
Traceback (most recent call last):
  File "Dogs.py", line 79, in <module>
    print(isinstance(julie, jim))
TypeError: isinstance() arg 2 must be a class, type, or tuple of classes and types

we tested if julie is an instance of jim, which is impossible since
jim is an instance of a class rather than a class itself - hence the reason for the
TypeError.
"""

# overiding examples
#frank = SomeBreed()
#print(frank.species)

#beans = SomeOtherBreed()
#print(beans.species)


# Create instance of dogs
my_dogs = [ BullDog("Tom", 6), RussellTerrier("Fletcher", 7), Dog("Larry", 9)]

# Instantiate the Pets class
my_pets = Pets(my_dogs)

# Output
print("I have {} dogs".format(len(my_pets.dogs)))
for dog in my_pets.dogs:
	print("{} is {}".format(dog.name, dog.age))

print("And they're all {}s, of course.".format(dog.species))
